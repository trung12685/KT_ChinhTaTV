# Kiểm thử chấp nhận trên Windows (chưa thực hiện trong cloud Linux)

1. Chạy core checks và mở giao diện bằng các lệnh trong README. Nếu chưa cài Word, khi mở file phải hiển thị thông báo dễ hiểu.
2. Sao chép file mẫu, tính SHA256 trước thử: `Get-FileHash samples/VanBanMau.docx`.
3. Mở file mẫu. Kỳ vọng 5 cảnh báo: quốc hiệu, khoảng trắng và ba vị trí `đo` (đoạn, bảng, trang hai). Câu `Tôi đo chiều dài` và `con đò` không bị cảnh báo.
4. Bản 0.1.2: lúc mở không có highlight. Chọn/rê chuột từng lỗi: chỉ lỗi đó có khung vàng; khung cũ phải biến mất, danh sách phải chọn đúng lỗi tương ứng. Kiểm tra ba từ `đo` giống nhau ở đoạn, bảng và trang hai để loại trừ việc tô lần xuất hiện đầu. Kiểm tra khoảng trắng chỉ tô khoảng trắng, quốc hiệu tô từng dòng khi xuống dòng. Chuyển qua lại ít nhất 20 lần; ghi thời gian `Đánh dấu` và thời gian cảm nhận, không xuất Word lại. Đổi zoom 50/100/150/200%, cuộn, đổi kích thước cửa sổ và kiểm tra khung luôn đi theo chữ. Thử trang có nhiều font, header/footer, ô gộp và văn bản lặp. Khi không ánh xạ chắc chắn, phải có thông báo và không tô vị trí khác. Sau sửa/hoàn tác, phải bỏ khung/index cũ, dựng lại và đánh dấu đúng nội dung mới. Ghi thời gian quét/dựng trang để so sánh cùng file/máy với 0.1.1.
5. Sửa `đo` ở trang hai; kiểm tra hai vị trí còn lại chưa thay đổi. Hoàn tác phải phục hồi đúng từ và số cảnh báo.
6. Sửa quốc hiệu: kiểm tra hoa, đậm, cỡ 13, font và căn giữa trong Word. Hoàn tác một lần phải phục hồi cả nội dung và định dạng.
7. Sửa khoảng trắng, lưu tên mới. Mở bản mới bằng Word, xác nhận không có màu highlight phát sinh; bảng, ngắt trang và các định dạng không liên quan còn nguyên. Kiểm tra SHA256 file gốc không thay đổi.
8. Thử mở file khác/đóng ứng dụng khi chưa lưu: chọn Không phải giữ phiên hiện tại; chọn Có mới bỏ bản sửa. Không được đóng phiên Word người dùng đã mở trước đó.
9. Thử tài liệu thực tế có ô gộp, nhiều font, trường tự động và nhiều trang. So sánh bản xem trước với Word trên cùng máy; ghi riêng các khác biệt, không khẳng định giống hệt trước khi so sánh.
10. Thử tài liệu có Track Changes, bảo vệ, file lỗi và file đang bị khóa. Kiểm tra thông báo lỗi, mở lại file hợp lệ và không để lại Word chạy ngầm sau khi thoát. Kiểm tra thư mục tạm `ChinhTa-*` được dọn sau phiên bình thường.
11. Tắt mạng sau khi build, chạy lại mở/quét/sửa/lưu để xác nhận offline. Thử trên bản sao tài liệu, không dùng duy nhất bản tài liệu gốc.

Ghi kết quả cùng phiên bản Windows, Word, .NET và cấu hình máy. Chỉ công bố các bước thực sự đã chạy.

12. Bản 0.1.3: mở/đóng/chuyển giữa hai tài liệu ít nhất 10 lần. Xác minh tiến trình Word riêng cũ kết thúc và các phiên Word có sẵn của người dùng vẫn hoạt động.
13. Trên máy thử nghiệm, với file giả, xác định đúng PID Word do ứng dụng tạo (không chọn Word người dùng), kết thúc PID đó rồi chọn Quét lại. Kiểm tra khôi phục nội dung đã checkpoint, thông báo mất lịch sử Undo và highlight mới; không tự lặp sửa. Nếu Word không khởi động được sau một lần thử, hiển thị thông báo dễ hiểu và đường dẫn nhật ký, không thử vô hạn.
14. Sửa rồi hoàn tác, lưu bản sao và so sánh nội dung/định dạng để xác minh checkpoint không phá Undo. Thử lỗi quyền lưu bản làm việc: phải báo, không tự khôi phục rồi âm thầm bỏ thay đổi. Kiểm tra nhật ký không chứa nội dung tài liệu.

15. Bản 0.1.4: mở lại đúng file từng gây lỗi 0x800706BE ở bước lấy trang. Thử lặp 10 lần, kiểm tra highlight đầu/cuối trang và cụm lặp. Nhật ký mới phải có `v0.1.4.0`; nếu còn lỗi, gửi các dòng mới cùng stack để xác định điểm lỗi mới. Không kết luận Office đã ổn định chỉ từ kiểm thử core trên Linux.

16. Bản 0.1.5: mở file mẫu có 5 cảnh báo, tích hai lỗi ở hai trang khác nhau. Rê chuột qua lỗi khác: highlight đổi nhưng hai ô tích không mất. Sửa các lỗi đã tích, xác nhận chỉ hai lỗi đổi, lỗi không tích giữ nguyên. Hoàn tác một lần phải phục hồi cả hai (nội dung, định dạng nếu có).
17. Bỏ tích tất cả rồi bấm sửa các lỗi đã tích: phải báo chưa chọn và không sửa. Tích tất cả/bỏ tích phải cập nhật số lượng và ô tích; cuộn danh sách ra/vào không mất trạng thái. Hủy hộp xác nhận không thay đổi tài liệu.
18. Sửa tất cả lỗi khi chưa tích mục nào: phải liệt kê số gợi ý, có cảnh báo gợi ý cần duyệt; xác nhận sửa toàn bộ và chỉ dựng lại preview một lần. Hoàn tác một lần phục hồi toàn bộ; lưu bản sao kiểm tra file gốc nguyên vẹn. Kiểm tra hai lỗi khoảng trắng gây đổi độ dài và lỗi ngữ cảnh phía sau không bị sửa sai vị trí. Sau quét các ô tích phải đặt lại.
19. Thử lỗi giữa lượt sửa trên file giả: thông báo có thể sửa một phần, không tự chạy lại lượt sửa; không tuyên bố toàn bộ thành công. Kiểm tra Hoàn tác khi Word còn hoạt động, và checkpoint gần nhất nếu Word đã mất kết nối.
